# SparkVPN Configuration
USERNAME = 'amir'
PASSWORD = 'sparkvpn'
static_configs = [
  'vless://c521e9d8...موقتی',
  'vless://c521e9d8...vision',
  'vless://9b915198...tcp#Sparkvpn',
  'vless://c521e9d8...فرانسه'
]
