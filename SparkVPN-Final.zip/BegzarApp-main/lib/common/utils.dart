class Utils {
  static const enc_key = "IYqSJoHyqHmC8K2jbiGqppR25xjNM2wo";
}