import 'package:flutter/material.dart';

class ThemeColor {
  static final backgroundColor = Color(0xff192028);
  static final foregroundColor = Color(0xffF7FAFF);
}