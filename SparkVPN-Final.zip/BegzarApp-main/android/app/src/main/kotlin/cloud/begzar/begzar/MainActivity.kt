package cloud.begzar.begzar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
